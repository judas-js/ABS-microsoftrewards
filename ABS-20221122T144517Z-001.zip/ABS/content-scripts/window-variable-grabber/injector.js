injectScript('/content-scripts/window-variable-grabber/main.js');
